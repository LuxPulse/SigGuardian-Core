pub const ENCRYPTION_KEY: &[u8; 32] = b"fluxxguard-32byte-secure-key-007";
pub const GEOLOCATION_API: &str = "https://ipapi.co/json/";
pub const THREAT_API: &str = "https://threatintel.mindofluxx.com/v1/analyze";
pub const SELF_DESTRUCT_DELAY_MS: u64 = 5000; // 5-second delay before purge